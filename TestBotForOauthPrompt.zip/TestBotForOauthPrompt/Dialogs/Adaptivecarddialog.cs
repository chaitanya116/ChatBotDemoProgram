﻿using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Schema;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace EchoBot.Dialogs
{
    public class Adaptivecarddialog : WaterfallDialog
    {
        public const string cards = @"./AdaptiveCard.json";
        
        public Adaptivecarddialog(string dialogId, IEnumerable<WaterfallStep> steps = null)
            : base(dialogId, steps)
        {
            AddStep(async (stepContext, cancellationToken) =>
            {
                var cardAttachment = CreateAdaptiveCardAttachment(cards);

                var reply = stepContext.Context.Activity.CreateReply();
                reply.Attachments = new List<Attachment>() { cardAttachment };

                await stepContext.Context.SendActivityAsync(reply, cancellationToken);
                var opts = new PromptOptions
                {
                    Prompt = new Activity
                    {
                        Type = ActivityTypes.Message,
                        // You can comment this out if you don't want to display any text. Still works.
                    }
                };

                // Display a Text Prompt and wait for input
                return await stepContext.PromptAsync(nameof(TextPrompt), opts);
            });

            AddStep(async (stepContext, cancellationToken) =>
            {
                var res = stepContext.Result.ToString();
                dynamic jobject = JsonConvert.DeserializeObject(res);
                string NewStartDateTime = jobject.Startdate + " " + jobject.Starttime;
                string NewStopDateTime = jobject.Stopdate + " " + jobject.Stoptime;
                CultureInfo provider = CultureInfo.InvariantCulture;
                DateTime dt = DateTime.Parse(NewStartDateTime);

                NewStartDateTime = dt.ToString("yyyy-MM-dd HH:mm");
                DateTime StartDateTime = DateTime.ParseExact(NewStartDateTime, "yyyy-MM-dd HH:mm", provider);

                dt = DateTime.Parse(NewStopDateTime);
                NewStopDateTime = dt.ToString("yyyy-MM-dd HH:mm");
                DateTime StopDateTime = DateTime.ParseExact(NewStopDateTime, "yyyy-MM-dd HH:mm", provider);

                await stepContext.Context.SendActivityAsync($"StartDateTime:{NewStartDateTime}", cancellationToken: cancellationToken);
                await stepContext.Context.SendActivityAsync($"StopDateTime:{NewStopDateTime}", cancellationToken: cancellationToken);

                return await stepContext.EndDialogAsync();
            });

        }

        public static new string Id => "Adaptivecarddialog";

        public static Adaptivecarddialog Instance { get; } = new Adaptivecarddialog(Id);

        public static Attachment CreateAdaptiveCardAttachment(string filePath)
        {
            var adaptiveCardJson = File.ReadAllText(filePath);
            var adaptiveCardAttachment = new Attachment()
            {
                ContentType = "application/vnd.microsoft.card.adaptive",
                Content = JsonConvert.DeserializeObject(adaptiveCardJson),
            };
            return adaptiveCardAttachment;
        }
    }
}
