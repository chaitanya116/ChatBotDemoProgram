﻿using Microsoft.Bot.Builder;
using Microsoft.Bot.Builder.AI.QnA;
using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Schema;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace EchoBot.Dialogs
{
    public class LoginDialog : WaterfallDialog
    {
        private string cards = @"./AdaptiveCard.json";
        private string translatedtext;
        private string langdetected;
        public LoginDialog(string dialogId, IEnumerable<WaterfallStep> steps = null)
             : base(dialogId, steps)
        {
            AddStep(async (stepContext, cancellationToken) =>
            {

                await stepContext.Context.SendActivityAsync("Please login using below option in order to continue with other options...");

              //  string lang = "zz";


                return await stepContext.BeginDialogAsync(PropertyDataClass.LoginPromptName, cancellationToken: cancellationToken); // This actually calls the  dialogue of OAuthPrompt whose name is  in EchoWithCounterBot.LoginPromptName.  

            });

            AddStep(async (stepContext, cancellationToken) =>
            {
                TokenResponse Tokenresponse = (TokenResponse)stepContext.Result;

                if (Tokenresponse != null)
                {

                    await stepContext.Context.SendActivityAsync($"logged in successfully... ");
                    await stepContext.Context.SendActivityAsync($"Token: {Tokenresponse.Token}");
                  
                    return await stepContext.BeginDialogAsync(Adaptivecarddialog.Id); //Here it goes To another dialogue class where options are displayed
                }
                else
                {
                    await stepContext.Context.SendActivityAsync("Login was not successful, Please try again...", cancellationToken: cancellationToken);


                    await stepContext.BeginDialogAsync("loginprompt", cancellationToken: cancellationToken);
                }

                return await stepContext.EndDialogAsync();
            });


        }

        public static new string Id => "LoginDialog";

        public static LoginDialog Instance { get; } = new LoginDialog(Id);

        private static Attachment CreateAdaptiveCardAttachment(string filePath)
        {
            var adaptiveCardJson = File.ReadAllText(filePath);
            var adaptiveCardAttachment = new Attachment()
            {
                ContentType = "application/vnd.microsoft.card.adaptive",
                Content = JsonConvert.DeserializeObject(adaptiveCardJson),
            };
            return adaptiveCardAttachment;
        }

    }
}

