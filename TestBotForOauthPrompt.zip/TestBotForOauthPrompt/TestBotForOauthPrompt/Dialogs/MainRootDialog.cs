﻿using Microsoft.Bot.Builder;
using Microsoft.Bot.Builder.Dialogs;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EchoBot.Dialogs
{
    public class MainRootDialog : ComponentDialog
    {
        private IStatePropertyAccessor<JObject> _userStateAccessor;
        public const string ConnectionName = "";
       // public static string LoginPrompt = "loginprompt";
        public MainRootDialog(UserState userState)
            : base("root")
        {
            _userStateAccessor = userState.CreateProperty<JObject>("result");
           

            AddDialog(Prompt(ConnectionName));
            AddDialog(LoginDialog.Instance);
            AddDialog(Adaptivecarddialog.Instance);
            AddDialog(new TextPrompt(nameof(TextPrompt)));         

            InitialDialogId = Adaptivecarddialog.Id;
        }

        private static OAuthPrompt Prompt(string connectionName)
        {
            return new OAuthPrompt(
               PropertyDataClass.LoginPromptName,
               new OAuthPromptSettings
               {
                   ConnectionName = connectionName,
                   Text = "Please Sign In",
                   Title = "Sign In",
                   Timeout = 300000, // User has 5 minutes to login (1000 * 60 * 5)
               });
        }
    }
}
