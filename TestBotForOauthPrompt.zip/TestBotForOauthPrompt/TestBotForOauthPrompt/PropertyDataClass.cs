﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EchoBot
{
    public static class PropertyDataClass
    {
        public static string LoginPromptName = "loginPrompt";
    }
}
